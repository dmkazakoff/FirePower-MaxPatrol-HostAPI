#!/bin/bash
unzip export.zip
for file in /Volume/home/admin/export/*.txt
do
  echo "=> Importing file $file"
  sudo /usr/local/sf/bin/nmimport.pl "$file"
done
rm -rf /Volume/home/admin/export/*
rm -rf /Volume/home/admin/export.zip